﻿using System.ComponentModel.DataAnnotations;

namespace ToolMonitoringServices.Model
{
    public class ToolCategories
    {
        [Key]
        public long ToolCategoryID { get; set; }
        public string ToolCategoryName { get; set; } = string.Empty;

        public long LocID { get; set; }
        //public string StrokeCount { get; set; } = string.Empty;
    }
}
                