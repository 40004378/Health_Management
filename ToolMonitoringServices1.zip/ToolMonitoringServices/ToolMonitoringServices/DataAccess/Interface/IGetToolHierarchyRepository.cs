﻿using ToolMonitoringServices.Model;

namespace ToolMonitoringServices.DataAccess.Interface
{
    
        public interface IGetToolHierarchyRepository
        {
            Task<List<Node>> GetHierarchy();

        //Task<List<Node>> GetNodes();
        }

   
    
}
